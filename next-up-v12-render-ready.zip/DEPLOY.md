# Publish Next Up! on Render

This is the same V12 game with public-hosting-compatible lobby QR invitations.

## Required: a Git repository

1. Create a new repository on GitHub, GitLab, or Bitbucket.
2. Upload **the files inside this folder** to the repository root (`server.js`, `package.json`, `public/`, `render.yaml`, etc.). Do not upload the ZIP as a single file.
3. In Render, connect that repository and create a **Web Service** using the included render.yaml or configure it manually.
4. If configuring manually, use Node runtime, `npm install --omit=dev` build, `npm start` start, and port set automatically by Render. The app listens on `process.env.PORT`.
5. Once Render deploys, open the `https://...onrender.com` URL and create a room. The QR invite uses `RENDER_EXTERNAL_URL` automatically supplied by Render.

## Caveats

- Rooms live in server memory. Free services can sleep, and restarting loses room state.
- The game has not been validated in live multiplayer sessions on Render.
- QR codes on localhost still point to the host machine's LAN IP and require the same network.
