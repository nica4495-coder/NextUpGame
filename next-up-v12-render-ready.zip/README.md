# Next Up! V5 — Sports World Playtest

## Run in VS Code

1. Install Node.js LTS if needed.
2. Open this extracted project folder (the folder with `package.json`) in VS Code.
3. Select **Terminal → New Terminal**.
4. Run `npm install`, then `npm start`.
5. Open **http://localhost:3000** in a browser (do not double-click `index.html`).
6. Create a room. Other players can join with the six-character room code.

For other devices on the same Wi-Fi, use your computer's LAN IP with port 3000. Keep the server running.

## V5 changes

- Four eight-space sports loops: Basketball (upper left), Football (upper right), Soccer (lower left), Hockey (lower right).
- Direct top bridge between Basketball and Football; direct bottom bridge between Soccer and Hockey.
- Everyone starts in the center on a left/right horizontal path. A separate north/south bridge crosses above/below the start without connecting at the crossing.
- Real graph-based map connectivity. At a junction, players choose a connected direction. Maximum one route decision per turn; remaining steps continue automatically.
- Colorful stadium-themed backgrounds, sports balls, jerseys, scoring equipment and goals, high-contrast player characters with names and colors.
- Six sports mini-games, sports trivia, 2–8 players, eight rounds, first to 60 Minutes wins.

## Playtest limitations

- Junctions reached later during a roll are traversed automatically after the turn's route choice. This can be refined with mid-roll route prompts in a later update.
- Sports artwork is stylized and includes SVG decorations and emoji, not licensed professional-team graphics.
- Room data is in memory, and disconnected players cannot rejoin an active game.
- Mini-game scores are client-reported and are not anti-cheat hardened.
- The game has not been tested end-to-end with multiple real devices in this environment.


## V6 visual update
- Launch screen sports emoji illustrations are in a separate responsive grid, not behind the welcome text.
- Board now includes 30 distinct sports-related emoji decorations distributed across the map.
- Core game logic, characters, map connectivity, and scoring are unchanged from V5.


## V7 updates
- Current player's location is highlighted on the board and named in a junction status strip. During route choice it pulses.
- Direction buttons now read West End-Zone, East End-Zone, North Goal, and South Goal, based on travel direction.
- Basketball and Football region labels appear above their circles; Soccer and Hockey region labels appear below their circles. Large sport emojis appear in each circle.
- Expanded general-interest trivia with famous basketball, football, soccer and hockey players and major events.

V8 naming fix: North Overpass and South Underpass route locations now display North Goal and South Goal; junction banner says Route Choice.


## V9 movement fix
After selecting a route, automatic movement follows only unambiguous paths. If another junction has multiple exits, movement stops there rather than choosing the north/top exit automatically. On the next turn the player chooses the next exit. Unused die steps are forfeited at that junction to preserve one route decision per turn.

## V10: Stadium names
Each of the 32 arena spaces now has a recognizable stadium or arena name instead of a numbered generic field. These are location labels for the fictional game board, not affiliations or endorsements. Gameplay and movement are unchanged from V9.

V11: Verified venue naming, removed invented hockey suffixes, and renamed junction locations to sports regions. Route choices remain North Goal, South Goal, West End-Zone, East End-Zone.

## V12 updates
- Route choices now display N, E, S, or W (no End-Zone / Goal suffix).
- Every player selects their own sports emoji and character background color when creating or joining. Choices are shown in the lobby and on the board.
- Duplicate names in the same room are rejected case-insensitively.
- Lobby includes a QR code for joining on another device on the same Wi-Fi. The server generates a LAN invite address; allow the Node server through your computer's firewall if prompted. QR links require the host computer and other devices to be reachable on the same network.
- Start the host with `npm install` then `npm start`; QR generation uses the `qrcode` package.
