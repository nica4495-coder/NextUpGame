const http = require("http");
const fs = require("fs");
const path = require("path");
const os = require("os");
const QRCode = require("qrcode");
const { WebSocketServer, WebSocket } = require("ws");

const PORT = process.env.PORT || 3000;
const PUBLIC = path.join(__dirname, "public");
const rooms = new Map();

// Four sports arenas with real bridges and a grade-separated center crossing.
// The horizontal START path and vertical overpass do not connect at their crossing.
const TRACK = [
 {name:"Center Start",type:"start",icon:"🏁",x:50,y:50},
 {name:"Basketball / Soccer Region",type:"junction",icon:"↕️",x:34,y:50},
 {name:"Football / Hockey Region",type:"junction",icon:"↕️",x:66,y:50}
];
const LOOP_TYPES=["minutes","trivia","minigame","mystery","minutes","challenge","trivia","special"];
// Distinct real-world venue names for each themed arena; used as map-space labels.
const VENUES=[
 ["Madison Square Garden","Intuit Dome","TD Garden","Chase Center","United Center","Kaseya Center","Barclays Center","Ball Arena"],
 ["Wembley Stadium","Spotify Camp Nou","Estadio Santiago Bernabéu","Anfield","Old Trafford","San Siro","Allianz Arena","Estádio do Maracanã"],
 ["Lambeau Field","Arrowhead Stadium","AT&T Stadium","Levi's Stadium","Lincoln Financial Field","Soldier Field","Highmark Stadium","SoFi Stadium"],
 ["Bell Centre","Scotiabank Arena","Madison Square Garden","United Center","Rogers Place","Climate Pledge Arena","TD Garden","Amalie Arena"]
];
const LOOP_ICONS=["🏀","⚽","🏈","🏒"];
for(let q=0;q<4;q++){
 const cx=q<2?24:76, cy=q%2===0?24:76;
 for(let i=0;i<8;i++){
  const angle=-Math.PI/2+i*Math.PI/4;
  TRACK.push({name:VENUES[q][i],type:LOOP_TYPES[i],icon:i===0?LOOP_ICONS[q]:({minutes:"⏱️",trivia:"🧠",minigame:"🎮",mystery:"❔",challenge:"🏆",special:"✨"}[LOOP_TYPES[i]]),x:cx+Math.cos(angle)*12,y:cy+Math.sin(angle)*12,loop:q});
 }
}
// Top bridge, bottom bridge, and two separate vertical overpass points.
TRACK.push({name:"Basketball / Football Region",type:"junction",icon:"🌉",x:50,y:12}); // 35
TRACK.push({name:"Soccer / Hockey Region",type:"junction",icon:"🌉",x:50,y:88}); // 36
TRACK.push({name:"Basketball / Football Region",type:"junction",icon:"⬆️",x:50,y:35}); // 37
TRACK.push({name:"Soccer / Hockey Region",type:"junction",icon:"⬇️",x:50,y:65}); // 38
const EDGES=TRACK.map(()=>[]);
function link(a,b){if(!EDGES[a].includes(b))EDGES[a].push(b);if(!EDGES[b].includes(a))EDGES[b].push(a);}
link(0,1);link(0,2);
for(let q=0;q<4;q++){let base=3+q*8;for(let i=0;i<8;i++)link(base+i,base+(i+1)%8);}
// Side access paths: the two options at each side junction are UP or DOWN.
link(1,5);link(1,13);link(2,25);link(2,33);
// Basketball <-> Football and Soccer <-> Hockey direct bridges.
link(3,35);link(35,19);link(11,36);link(36,27);
// North-south route crosses START without intersecting it.
link(35,37);link(37,38);link(38,36);
function available(room,p){
 const neighbors=EDGES[p.position];
 if(p.previous===null || p.previous===undefined)return neighbors;
 return neighbors.filter(n=>n!==p.previous);
}
function directionName(from,to){
 const a=TRACK[from],b=TRACK[to];
 const dx=b.x-a.x,dy=b.y-a.y;
 if(Math.abs(dx)>Math.abs(dy))return dx<0?"W":"E";
 return dy<0?"N":"S";
}
function optionsFor(room,p){return available(room,p).map(n=>({to:n,label:directionName(p.position,n),name:TRACK[n].name}));}
function advance(room,p,to){p.previous=p.position;p.position=to;}
function continueMovement(room,p,chosen){
 let remaining=room.pendingRoll||0;
 if(!remaining)return;
 if(!available(room,p).includes(chosen))return;
 advance(room,p,chosen);remaining--;
 let stoppedAtJunction=false;
 while(remaining>0){
  const opts=available(room,p);
  if(!opts.length)break;
  // Never silently choose an exit at a branching junction.
  // The player already chose once this turn, so stop and let them
  // choose the next route on their following turn.
  if(opts.length>1){stoppedAtJunction=true;break;}
  advance(room,p,opts[0]);remaining--;
 }
 room.pendingRoll=null;room.choiceUsed=false;
 room.message=stoppedAtJunction
  ? `${p.name} reached ${TRACK[p.position].name}. Choose your next route on your next turn.`
  : `${p.name} arrived at ${TRACK[p.position].name}.`;
 update(room);triggerSpace(room,p);
}

const QUESTIONS = [
  { q: "How many players from one team are on the court in basketball?", options: ["4", "5", "6", "7"], answer: 1 },
  { q: "How often are the Summer Olympic Games normally held?", options: ["Every 2 years", "Every 3 years", "Every 4 years", "Every 5 years"], answer: 2 },
  { q: "In soccer, what is it called when a player scores three goals in one match?", options: ["Hat trick", "Triple play", "Three-pointer", "Clean sweep"], answer: 0 },
  { q: "How many strikes make an out in baseball?", options: ["2", "3", "4", "5"], answer: 1 },
  { q: "What surface is traditionally used at Wimbledon?", options: ["Clay", "Hard court", "Grass", "Carpet"], answer: 2 },
  { q: "How many periods are in a standard ice hockey game?", options: ["2", "3", "4", "5"], answer: 1 },
  { q: "Which sport uses the terms 'birdie' and 'eagle'?", options: ["Golf", "Tennis", "Badminton", "Cricket"], answer: 0 },
  { q: "How many points is a touchdown worth before the extra point attempt?", options: ["3", "5", "6", "7"], answer: 2 },
  { q: "Which NBA legend is nicknamed Air Jordan?", options: ["Kobe Bryant", "Michael Jordan", "LeBron James", "Stephen Curry"], answer: 1 },
  { q: "Which NBA star is widely known as King James?", options: ["Kevin Durant", "Shaquille O’Neal", "LeBron James", "Magic Johnson"], answer: 2 },
  { q: "Which NBA player is famous for his long-range three-point shooting with the Golden State Warriors?", options: ["Stephen Curry", "Tim Duncan", "Dwyane Wade", "Dirk Nowitzki"], answer: 0 },
  { q: "Which basketball legend was nicknamed the Black Mamba?", options: ["Larry Bird", "Kobe Bryant", "Michael Jordan", "Charles Barkley"], answer: 1 },
  { q: "Which quarterback won seven Super Bowls?", options: ["Peyton Manning", "Patrick Mahomes", "Tom Brady", "Aaron Rodgers"], answer: 2 },
  { q: "Which NFL legend was nicknamed Megatron?", options: ["Calvin Johnson", "Jerry Rice", "Randy Moss", "Rob Gronkowski"], answer: 0 },
  { q: "Which team did Patrick Mahomes lead to a Super Bowl victory in 2020?", options: ["New England Patriots", "Kansas City Chiefs", "Dallas Cowboys", "Green Bay Packers"], answer: 1 },
  { q: "Which NFL team plays its home games at Lambeau Field?", options: ["Chicago Bears", "Buffalo Bills", "Green Bay Packers", "Seattle Seahawks"], answer: 2 },
  { q: "Which soccer superstar is famous for playing for Argentina and winning the 2022 World Cup?", options: ["Lionel Messi", "Cristiano Ronaldo", "Kylian Mbappé", "Neymar"], answer: 0 },
  { q: "Which soccer star is known for his famous 'Siuuu' goal celebration?", options: ["Erling Haaland", "Cristiano Ronaldo", "Luka Modrić", "Harry Kane"], answer: 1 },
  { q: "Which country won the men's FIFA World Cup in 2022?", options: ["France", "Brazil", "Argentina", "Germany"], answer: 2 },
  { q: "Which soccer star scored a hat trick in the 2022 men's World Cup final?", options: ["Kylian Mbappé", "Lionel Messi", "Neymar", "Mohamed Salah"], answer: 0 },
  { q: "Which hockey legend is nicknamed The Great One?", options: ["Mario Lemieux", "Wayne Gretzky", "Sidney Crosby", "Alex Ovechkin"], answer: 1 },
  { q: "Which NHL star is nicknamed Sid the Kid?", options: ["Connor McDavid", "Wayne Gretzky", "Sidney Crosby", "Nathan MacKinnon"], answer: 2 },
  { q: "Which hockey player famously scored the golden goal for Canada at the 2010 Winter Olympics?", options: ["Sidney Crosby", "Alex Ovechkin", "Patrick Kane", "Wayne Gretzky"], answer: 0 },
  { q: "What trophy does the NHL champion win?", options: ["Lombardi Trophy", "Stanley Cup", "World Series Trophy", "Larry O’Brien Trophy"], answer: 1 }
];

const MINI_GAMES = [
  { key: "basketball", sport: "Basketball", title: "Buzzer-Beater", instruction: "Stop the moving shot meter inside the green zone. You get 5 shots.", mechanic: "timing" },
  { key: "football", sport: "Football", title: "Quarterback Reads", instruction: "Read the called receiver and throw to the matching route. You get 5 passes.", mechanic: "target" },
  { key: "soccer", sport: "Soccer", title: "Penalty Shootout", instruction: "Pick the corner called by your coach before the keeper blocks it. You get 5 kicks.", mechanic: "choice" },
  { key: "baseball", sport: "Baseball", title: "Home Run Timing", instruction: "Swing when the pitch reaches the hit zone. You get 5 pitches.", mechanic: "reaction" },
  { key: "tennis", sport: "Tennis", title: "Rally Recall", instruction: "Memorize the shot sequence, then repeat it using the direction buttons.", mechanic: "sequence" },
  { key: "hockey", sport: "Hockey", title: "Slapshot Accuracy", instruction: "Aim for the open lane around the goalie. You get 5 shots.", mechanic: "choice" }
];

const COLORS = ["#ff6b4a", "#4e9cff", "#a879f5", "#24b88a", "#f2b84b", "#ec72b7", "#52c7d5", "#9aa5b1"];
const SPORTS = ["🏀 Hooper", "🏈 Gridiron", "⚽ Striker", "⚾ Slugger", "🎾 Ace", "🏒 Rinkstar", "🏐 Spiker", "🏉 All-Rounder"];

function code() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let s = "";
  for (let i = 0; i < 6; i++) s += chars[Math.floor(Math.random() * chars.length)];
  return s;
}
function safeAvatar(v) { return SPORTS.includes(v) ? v : SPORTS[0]; }
function safeColor(v) { return COLORS.includes(v) ? v : COLORS[0]; }
function nameTaken(room,name) { return room.players.some(p=>p.name.trim().toLocaleLowerCase()===name.trim().toLocaleLowerCase()); }
function safeName(v) {
  return String(v || "Player").replace(/[<>]/g, "").trim().slice(0, 18) || "Player";
}
function send(ws, obj) {
  if (ws && ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(obj));
}
function broadcast(room, obj) {
  for (const p of room.players) send(p.ws, obj);
}
function publicState(room) {
  return {
    code: room.code, status: room.status, round: room.round, maxRounds: 8,
    currentIndex: room.currentIndex, phase: room.phase, maxMinutes: 60, choices: current(room) ? optionsFor(room,current(room)) : [],
    activeJunction: current(room) ? {position:current(room).position,name:TRACK[current(room).position].name,playerId:current(room).id,playerName:current(room).name} : null,
    players: room.players.map((p, i) => ({
      id: p.id, name: p.name, avatar: p.avatar, color: p.color, minutes: p.minutes,
      position: p.position, ready: p.ready, isHost: i === 0,
      connected: !!p.ws
    })),
    track: TRACK,
    event: room.event ? {
      type: room.event.type, title: room.event.title, description: room.event.description,
      participants: room.event.participants, question: room.event.question,
      options: room.event.question?.options, miniGame: room.event.miniGame, deadline: room.event.deadline,
      submissions: room.event.submissions ? Object.keys(room.event.submissions).length : 0,
      startedAt: room.event.startedAt
    } : null,
    message: room.message
  };
}
function award(room,p,amount){p.minutes=Math.min(60,Math.max(0,p.minutes+amount));}
function checkWin(room){
  const winners=room.players.filter(p=>p.minutes>=60);
  if(!winners.length)return false;
  room.status="finished";room.phase="finished";room.event=null;room.pendingRoll=null;
  room.message=`${winners.map(p=>p.name).join(" & ")} reached 60 Minutes and won Next Up!`;
  update(room);return true;
}
function update(room) { broadcast(room, { type: "state", state: publicState(room) }); }
function player(room, id) { return room.players.find(p => p.id === id); }
function current(room) { return room.players[room.currentIndex]; }
function finishTurn(room) {
  if(checkWin(room))return;
  room.phase = "turn";
  room.pendingRoll = null;
  room.event = null;
  room.message = `${current(room)?.name || "Next player"}'s turn.`;
  room.currentIndex++;
  if (room.currentIndex >= room.players.length) {
    room.currentIndex = 0;
    if (room.round >= 8) {
      room.status = "finished";
      room.phase = "finished";
      const sorted = [...room.players].sort((a,b) => b.minutes - a.minutes);
      room.message = sorted[0].minutes === sorted[1]?.minutes
        ? "It's a tie! The championship is shared."
        : `${sorted[0].name} wins Next Up!`;
    } else {
      room.round++;
      room.message = `Round ${room.round} begins!`;
    }
  }
  update(room);
}
function startEvent(room, type, title, description, participants, extra = {}) {
  room.phase = "event";
  room.event = {
    type, title, description, participants,
    submissions: {}, startedAt: Date.now(), deadline: Date.now() + (type === "minigame" ? 30000 : 25000),
    ...extra
  };
  update(room);
  const duration = type === "minigame" ? 30000 : 25000;
  const eventRef = room.event;
  setTimeout(() => {
    if (room.event === eventRef) resolveEvent(room);
  }, duration + 250);
}
function resolveEvent(room) {
  const ev = room.event;
  if (!ev) return;
  const ids = ev.participants;
  const entries = ids.map(id => ({ id, score: Number(ev.submissions[id]?.score || 0), answer: ev.submissions[id]?.answer }));
  if (ev.type === "trivia") {
    const correct = entries.filter(e => e.answer === ev.question.answer).sort((a,b) => (ev.submissions[a.id].at || 0) - (ev.submissions[b.id].at || 0));
    correct.forEach((e, i) => {
      const p = player(room, e.id);
      if (p) award(room,p,2 + (i === 0 ? 1 : 0));
    });
    room.message = correct.length ? `Trivia complete! ${correct.map(e => player(room,e.id)?.name).filter(Boolean).join(", ")} answered correctly.` : "No correct answers this time.";
  } else {
    entries.sort((a,b) => b.score - a.score);
    const awards = [5, 3, 2];
    entries.forEach((e, i) => {
      const p = player(room, e.id);
      if (p && e.score > 0) award(room,p,awards[i] || 1);
    });
    const winner = entries[0] && player(room, entries[0].id);
    room.message = winner && entries[0].score > 0 ? `${winner.name} wins the event and earns ${awards[0]} Minutes!` : "Event complete!";
  }
  // The event belongs to the player whose turn caused it; advance after results.
  finishTurn(room);
}
function triggerSpace(room, p) {
  const space = TRACK[p.position];
  if(space.type === "junction") {room.message=`${p.name} reached ${space.name}.`;finishTurn(room);return;}
  if (space.type === "start") {
    award(room,p,1);
    room.message = `${p.name} passed the starting line and earned 1 Minute.`;
    finishTurn(room); return;
  }
  if (space.type === "minutes") {
    award(room,p,2);
    room.message = `${p.name} collected 2 Minutes!`;
    finishTurn(room); return;
  }
  if (space.type === "mystery") {
    const outcomes = [
      { n: 3, text: "A surprise coach's bonus! +3 Minutes." },
      { n: 2, text: "Extra practice paid off! +2 Minutes." },
      { n: -2, text: "A scheduling penalty costs 2 Minutes." },
      { n: 0, text: "A mystery rest day. No change to Minutes." }
    ];
    const o = outcomes[Math.floor(Math.random() * outcomes.length)];
    award(room,p,o.n);
    room.message = `${p.name}: ${o.text}`;
    finishTurn(room); return;
  }
  if (space.type === "special") {
    const others = room.players.filter(x => x.id !== p.id);
    const leader = [...room.players].sort((a,b) => b.minutes-a.minutes)[0];
    if (leader && leader.id !== p.id && leader.minutes >= 2) {
      leader.minutes -= 3; award(room,p,2);
      room.message = `${p.name} earned a spotlight bonus and took 2 Minutes from the current leader!`;
    } else {
      award(room,p,2);
      room.message = `${p.name} received a 2-Minute spotlight bonus!`;
    }
    finishTurn(room); return;
  }
  if (space.type === "trivia") {
    const q = QUESTIONS[Math.floor(Math.random() * QUESTIONS.length)];
    startEvent(room, "trivia", "Sports Trivia", "Everyone answers on their own device. Correct answers earn 2 Minutes; the fastest correct answer earns 1 extra.", room.players.map(x => x.id), { question: q });
    return;
  }
  let participants;
  if (space.type === "challenge") {
    const opponent = room.players.filter(x => x.id !== p.id).sort(() => Math.random() - .5)[0];
    participants = opponent ? [p.id, opponent.id] : [p.id];
  } else {
    const mode = Math.random();
    if (mode < 0.4) participants = room.players.map(x => x.id);
    else if (mode < 0.8 && room.players.length > 1) {
      const opponent = room.players.filter(x => x.id !== p.id).sort(() => Math.random() - .5)[0];
      participants = opponent ? [p.id, opponent.id] : [p.id];
    } else participants = [p.id];
  }
  const miniGame = MINI_GAMES[Math.floor(Math.random() * MINI_GAMES.length)];
  const title = space.type === "challenge" ? `${miniGame.title} — Head-to-Head` : miniGame.title;
  const desc = `${miniGame.sport}: ${miniGame.instruction}`;
  startEvent(room, "minigame", title, desc, participants, { miniGame });
}
function handle(ws, msg) {
  if (!msg || typeof msg !== "object") return;
  if (msg.action === "create") {
    if (ws.roomCode) return;
    let c; do { c = code(); } while (rooms.has(c));
    const p = { id: cryptoId(), name: safeName(msg.name), avatar: safeAvatar(msg.avatar), color: safeColor(msg.color), minutes: 0, position: 0, previous: null, ready: true, ws };
    const room = { code: c, players: [p], hostId: p.id, status: "lobby", round: 1, currentIndex: 0, phase: "lobby", event: null, message: "Waiting for players to join." };
    rooms.set(c, room); ws.roomCode = c; ws.playerId = p.id;
    send(ws, { type: "joined", playerId: p.id, code: c }); update(room); return;
  }
  if (msg.action === "join") {
    if (ws.roomCode) return;
    const c = String(msg.code || "").toUpperCase().trim();
    const room = rooms.get(c);
    if (!room || room.status !== "lobby" || room.players.length >= 8) {
      send(ws, { type: "error", message: "Room not found, already started, or full." }); return;
    }
    const cleanName = safeName(msg.name);
    if (nameTaken(room,cleanName)) { send(ws,{type:"error",message:"That player name is already taken in this lobby. Choose another name."}); return; }
    const p = { id: cryptoId(), name: cleanName, avatar: safeAvatar(msg.avatar), color: safeColor(msg.color), minutes: 0, position: 0, previous: null, ready: true, ws };
    room.players.push(p); ws.roomCode = c; ws.playerId = p.id;
    send(ws, { type: "joined", playerId: p.id, code: c }); room.message = `${p.name} joined the room.`; update(room); return;
  }
  const room = rooms.get(ws.roomCode);
  if (!room) return;
  const p = player(room, ws.playerId);
  if (!p) return;
  if (msg.action === "ready" && room.status === "lobby") {
    p.ready = !!msg.ready; update(room);
  }
  if (msg.action === "start" && room.status === "lobby" && room.players[0].id === p.id) {
    if (room.players.length < 2 || !room.players.every(x => x.ready && x.ws)) { send(ws, { type: "error", message: "You need at least 2 connected, ready players to start." }); return; }
    room.status = "playing"; room.phase = "turn"; room.message = "Game on! " + current(room).name + " goes first."; update(room);
  }
  if (msg.action === "roll" && room.status === "playing" && room.phase === "turn" && current(room)?.id === p.id && !room.pendingRoll) {
    room.pendingRoll = Math.floor(Math.random() * 6) + 1;
    send(ws, { type: "rolled", value: room.pendingRoll });
  }
  if (msg.action === "move" && room.status === "playing" && room.phase === "turn" && current(room)?.id === p.id && room.pendingRoll) {
    const to=Number(msg.to);
    if(!available(room,p).includes(to)){send(ws,{type:"error",message:"Choose a valid connected path."});return;}
    continueMovement(room,p,to);
  }
  if (msg.action === "submit" && room.status === "playing" && room.phase === "event" && room.event?.participants.includes(p.id) && !room.event.submissions[p.id]) {
    const ev = room.event;
    if (ev.type === "trivia") {
      const answer = Number(msg.answer);
      ev.submissions[p.id] = { answer, at: Date.now() };
    } else {
      ev.submissions[p.id] = { score: Math.max(0, Math.min(1000, Number(msg.score) || 0)), at: Date.now() };
    }
    const done = ev.participants.every(id => !!ev.submissions[id]);
    update(room);
    if (done) resolveEvent(room);
  }
}
function cryptoId() { return Math.random().toString(36).slice(2, 11); }

function localIp() {
 for (const group of Object.values(os.networkInterfaces())) for (const addr of group || []) {
  if (addr.family === "IPv4" && !addr.internal) return addr.address;
 }
 return "localhost";
}
const server = http.createServer(async (req, res) => {
  const url = new URL(req.url || "/", "http://localhost");
  if (url.pathname === "/qr") {
    const roomCode = (url.searchParams.get("code") || "").toUpperCase();
    if (!/^[A-Z2-9]{6}$/.test(roomCode) || !rooms.has(roomCode)) { res.writeHead(404);res.end("Room not found");return; }
    // Render supplies its public HTTPS URL; for local play, use the LAN address so phones can scan.
    const publicOrigin = process.env.RENDER_EXTERNAL_URL?.trim().replace(/\/$/, "");
    const localOrigin = `http://${localIp()}:${PORT}`;
    const joinUrl = `${publicOrigin || localOrigin}/?code=${encodeURIComponent(roomCode)}`;
    try {
      const svg = await QRCode.toString(joinUrl,{type:"svg",width:230,margin:2,errorCorrectionLevel:"M"});
      res.writeHead(200,{"Content-Type":"image/svg+xml","Cache-Control":"no-store"});res.end(svg);
    } catch {res.writeHead(500);res.end("QR unavailable");}
    return;
  }

  let pathname = decodeURIComponent((req.url || "/").split("?")[0]);
  if (pathname === "/") pathname = "/index.html";
  const file = path.resolve(PUBLIC, "." + pathname);
  if (file !== PUBLIC && !file.startsWith(PUBLIC + path.sep)) { res.writeHead(403); res.end("Forbidden"); return; }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404); res.end("Not found"); return; }
    const ext = path.extname(file);
    const types = { ".html": "text/html", ".css": "text/css", ".js": "text/javascript", ".png": "image/png", ".svg": "image/svg+xml" };
    res.writeHead(200, { "Content-Type": types[ext] || "application/octet-stream" }); res.end(data);
  });
});
const wss = new WebSocketServer({ server });
wss.on("connection", ws => {
  ws.on("message", raw => {
    try { handle(ws, JSON.parse(raw.toString())); }
    catch (e) { send(ws, { type: "error", message: "Something went wrong. Please try again." }); }
  });
  ws.on("close", () => {
    const room = rooms.get(ws.roomCode);
    if (!room) return;
    const p = player(room, ws.playerId);
    if (p) p.ws = null;
    room.message = `${p?.name || "A player"} disconnected. They can reconnect by refreshing and rejoining if the lobby is still open.`;
    update(room);
    if (room.players.every(x => !x.ws)) rooms.delete(room.code);
  });
});
server.listen(PORT, () => console.log(`Next Up! running on http://localhost:${PORT}`));
